tar -czf lurker-0.1.tar.gz lurker-0.1
