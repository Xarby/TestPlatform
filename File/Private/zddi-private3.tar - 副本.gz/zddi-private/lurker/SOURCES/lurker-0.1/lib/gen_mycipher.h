#ifndef __GEN_MYCIPHER_H
#define __GEN_MYCIPHER_H
int gen_cipher();
int del_cipher();
#endif
