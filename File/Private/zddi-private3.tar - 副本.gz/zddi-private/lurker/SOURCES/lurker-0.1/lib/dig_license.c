#include <string.h>
#include <unistd.h>

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>

#include "dig_license.h"
#include "dig_fetch_info.h"

#define MAX_BUF_LEN 65535
#define SHA512_LEN  64
#define SHA256_LEN  32

#define ENCRYPTO_INC    16
#define MAX_ENCRYPTO_LEN    65535

#define MAX_QPS_LEN   10
#define QPS_SHIFT     33

#define MAX_DATETIME_LEN 20
#define MAX_CLIENT_ID_LEN 33

#define SIGN_START_POS  (8 * MAX_QPS_LEN + MAX_EMPTY_SIZE)

static int
decrypt_info(const uint8_t *key, const uint8_t *input_buf, int input_len,
        uint8_t *output_buf, int *output_len)
{
    EVP_CIPHER_CTX ctx;
    EVP_CIPHER_CTX_init(&ctx);
    const EVP_CIPHER *cipher = EVP_des_ede3_cbc();

    int ret = EVP_DecryptInit_ex(&ctx, cipher, NULL, key, NULL);
    if (1 != ret)
        return -1;

    int once_out = -1;
    EVP_DecryptUpdate(&ctx, output_buf, &once_out, input_buf, input_len);
    *output_len = once_out;
    ret = EVP_DecryptFinal_ex(&ctx, output_buf + once_out, &once_out);
    EVP_CIPHER_CTX_cleanup(&ctx);

    if (1 != ret)
        return -1;

    *output_len = *output_len + once_out;
    return 0;
}

static EVP_PKEY *
read_public_key_from_file(const char *public_key_file, int mem_direction, int disk_direction)
{
    if (!public_key_file || access(public_key_file, F_OK))
        return NULL;

    char machine_info_buf[MAX_INFO_LEN] = {0};
    int info_len = get_hardware_info(machine_info_buf, MAX_INFO_LEN, mem_direction, disk_direction);
    if (info_len <= 0)
        return NULL;

    uint8_t digest_buf[SHA512_LEN] = {0};
    SHA512((const unsigned char *)machine_info_buf, info_len, digest_buf);

    uint8_t ciph_key[SHA256_LEN] = {0};
    SHA256((const unsigned char *)digest_buf, SHA512_LEN, ciph_key);

    // read public key
    uint8_t encrypt_pubkey_buf[MAX_BUF_LEN] = {0};
    FILE *fp = fopen(public_key_file, "r");
    if (!fp) {
        return NULL;
    }
    size_t read_len = fread(encrypt_pubkey_buf, sizeof(uint8_t), MAX_BUF_LEN, fp);
    fclose(fp);
    if (read_len <= 0) {
        return NULL;
    }

    uint8_t decrypt_buf[MAX_ENCRYPTO_LEN] = {0};
    int decrypt_len = -1;

    int ret = decrypt_info(ciph_key, encrypt_pubkey_buf, read_len, decrypt_buf, &decrypt_len);
    if (ret) {
        return NULL;
    }

    const char *tmp_file = "/tmp/tmp_pubfile";
    fp = fopen(tmp_file, "w");
    if (!fp) {
        return NULL;
    }

    size_t write_len = fwrite(decrypt_buf, sizeof(uint8_t), decrypt_len, fp);
    fclose(fp);
    if (write_len != decrypt_len) {
        fprintf(stderr, "write tmp pubfile failed\n");
        return NULL;
    }


    BIO *public_in = BIO_new_file(tmp_file, "rb");
    if (!public_in)
        return NULL;

    RSA *public_key = NULL;
    public_key = PEM_read_bio_RSAPublicKey(public_in, &public_key, NULL, NULL);
    if (!public_key)
        return NULL;

    EVP_PKEY *pub_key = EVP_PKEY_new();
    if (!pub_key) {
        RSA_free(public_key);
        return NULL;
    }

    EVP_PKEY_assign_RSA(pub_key, public_key);
    return pub_key;
}
//读取指定的machine.info文件
//machine.info中存储的是:
// 通过 get_hardware_info 函数获取的信息经过SHA512加密后写入的
static int get_machine_info_from_file_sha512(char *file_digest)
{
   int ret = -1;
   FILE *machine_info_fp = NULL, *err_fp = NULL;
   machine_info_fp = fopen(MACHINE_FILE_PATH, "r"); 
   if (machine_info_fp) {
       fread(file_digest, sizeof(uint8_t), SHA512_LEN , machine_info_fp);
       fclose(machine_info_fp);
       return 0;
   }else{
       //无machine.info文件，返回true
       return -1;
   } 
}
//通过指定路径的machine.info获得pubkey
static EVP_PKEY *
read_public_key_for_valid_virtual(const char *public_key_file)
{
    if (!public_key_file || access(public_key_file, F_OK))
        return NULL;

    uint8_t digest_buf[SHA512_LEN] = {0};
    //读取失败返回NULL
    if( get_machine_info_from_file_sha512(digest_buf) ){
        return NULL;
    }
    uint8_t ciph_key[SHA256_LEN] = {0};
    SHA256((const unsigned char *)digest_buf, SHA512_LEN, ciph_key);

    // read public key
    uint8_t encrypt_pubkey_buf[MAX_BUF_LEN] = {0};
    FILE *fp = fopen(public_key_file, "r");
    if (!fp) {
        return NULL;
    }
    size_t read_len = fread(encrypt_pubkey_buf, sizeof(uint8_t), MAX_BUF_LEN, fp);
    fclose(fp);
    if (read_len <= 0) {
        return NULL;
    }

    uint8_t decrypt_buf[MAX_ENCRYPTO_LEN] = {0};
    int decrypt_len = -1;

    int ret = decrypt_info(ciph_key, encrypt_pubkey_buf, read_len, decrypt_buf, &decrypt_len);
    if (ret) {
        return NULL;
    }

    const char *tmp_file = "/tmp/tmp_pubfile";
    fp = fopen(tmp_file, "w");
    if (!fp) {
        return NULL;
    }

    size_t write_len = fwrite(decrypt_buf, sizeof(uint8_t), decrypt_len, fp);
    fclose(fp);
    if (write_len != decrypt_len) {
        fprintf(stderr, "write tmp pubfile failed\n");
        return NULL;
    }


    BIO *public_in = BIO_new_file(tmp_file, "rb");
    if (!public_in)
        return NULL;

    RSA *public_key = NULL;
    public_key = PEM_read_bio_RSAPublicKey(public_in, &public_key, NULL, NULL);
    if (!public_key)
        return NULL;

    EVP_PKEY *pub_key = EVP_PKEY_new();
    if (!pub_key) {
        RSA_free(public_key);
        return NULL;
    }

    EVP_PKEY_assign_RSA(pub_key, public_key);
    return pub_key;
}

static int     
verify_buf_with_public_key(const uint8_t *input_buf, int input_len,
        const uint8_t *sign_buf, int sign_len, EVP_PKEY *pub_key)
{
    if (!input_buf || (input_len <= 0) || !sign_buf || (sign_len <= 0) || !pub_key)
        return -1;

    EVP_MD_CTX md_ctx_verify;
    EVP_SignInit(&md_ctx_verify, EVP_sha1());

    EVP_VerifyUpdate(&md_ctx_verify, input_buf, input_len);
    int err = EVP_VerifyFinal(&md_ctx_verify, (unsigned char *)sign_buf, (unsigned int)sign_len, pub_key);
    if (1 != err) {
        ERR_print_errors_fp(stderr);
        return -1;
    }

    return 0;
}

int 
get_limit(const char *digest_file, int type)
{
    int start_pos = type * MAX_QPS_LEN;
    uint8_t value[MAX_QPS_LEN] = {0};
    if (get_key_value(digest_file, start_pos, MAX_QPS_LEN, value) < 0) {
        return -1;
    }
    return atoi(value);
}

//校验系统直接获取的machine和license失败，
// 再校验指定位置读取的machine文件与license
static int specified_file_verification(const char *public_key_file, uint8_t *digest_buf, size_t sign_len){
    int ret = -1;
    //通过指定位置读取的machine文件生成pubkey
    EVP_PKEY *pub_key = read_public_key_for_valid_virtual(public_key_file);

    FILE *machine_info_fp;
    uint8_t file_digest[SHA512_LEN] = {0};
    get_machine_info_from_file_sha512(file_digest);
    ret = verify_buf_with_public_key((const uint8_t *)file_digest, SHA512_LEN, digest_buf, (int)sign_len, pub_key);
    if (!ret) {
        EVP_PKEY_free(pub_key);
        return ret;
    }
      
     return ret; 
}

int
check_digest_for_license(const char *public_key_file, const char *license_file)
{
    int ret = -1;
    // check params
    if (!public_key_file || !license_file || access(public_key_file, F_OK) || access(license_file, F_OK)) {
        printf("access: %s failed\n", license_file);
        return ret;
    }

    uint8_t digest_buf[MAX_BUF_LEN] = {0};
    size_t sign_len = get_sign_buf(license_file, digest_buf, MAX_BUF_LEN);
    if (sign_len <= 0)
        return ret;

    char machine_info_buf[MAX_INFO_LEN] = {0};
    uint8_t info_digest[SHA512_LEN] = {0};
    int info_len, mem_direction, disk_direction;
    info_len = 0;

    // compare atmost 9 times: 3(mem_size) * 3(disk_size)
    // memory: [mem_size - 100, mem_size, mem_size + 100]
    // disk:   [disk_size - 100, disk_size, disk_size + 100]
    for (mem_direction = -1; mem_direction <= 1; mem_direction++) {
        for (disk_direction = -1; disk_direction <= 1; disk_direction++) {
            EVP_PKEY *pub_key = read_public_key_from_file(public_key_file, mem_direction, disk_direction);
            if (!pub_key) {
                continue;
            }

            info_len = get_hardware_info(machine_info_buf, MAX_INFO_LEN, mem_direction, disk_direction);
            if (info_len <= 0) {
                EVP_PKEY_free(pub_key);
                return ret;
            }
            SHA512((const unsigned char *)machine_info_buf, info_len, info_digest);
            ret = verify_buf_with_public_key((const uint8_t *)info_digest, SHA512_LEN, digest_buf, (int)sign_len, pub_key);
            if (!ret) {
                EVP_PKEY_free(pub_key);
                return ret;
            }               
        }
    }
    ret = specified_file_verification(public_key_file, digest_buf, sign_len);
    return ret;
}

int get_restart_param_length(const char *digest_file) {
    uint8_t value[MAX_QPS_LEN] = {0};
    size_t start_pos = 0;  
    if (get_key_value(digest_file, start_pos, MAX_QPS_LEN, value) < 0) {
        return -1;
    }
    return atoi(value);
}

int get_restart_param(const char* digest_file, char* out_buf, int out_buf_len) {
    size_t len = get_restart_param_length(digest_file); 
    if (len < 0) {
        fprintf(stderr, "get restart param length error\n");
        return -1;
    }

    if (len > out_buf_len) {
        fprintf(stderr, "the buffer size is smaller\n");
        return -1;
    }
    size_t start_pos = MAX_QPS_LEN;
    if (get_key_value(digest_file, start_pos, len, out_buf) < 0) {
        return -1;
    }
    return len;
}

int get_sign_length(const char *digest_file) {
    size_t restart_param_len = get_restart_param_length(digest_file);
    if (restart_param_len < 0) {
        fprintf(stderr, "get restart param length error\n");
        return -1;
    }

    uint8_t value[MAX_QPS_LEN] = {0};
    size_t start_pos = MAX_QPS_LEN + restart_param_len;  
    if (get_key_value(digest_file, start_pos, MAX_QPS_LEN, value) < 0) {
        return -1;
    }
    return atoi(value);
}

int get_extend_license_length(const char *digest_file) {
    
    size_t restart_param_len = get_restart_param_length(digest_file);
    if (restart_param_len < 0) {
        fprintf(stderr, "get restart param length error\n");
        return -1;
    }

    size_t sign_len = get_sign_length(digest_file); 
    if (sign_len < 0) {
        fprintf(stderr, "get sign length error\n");
        return -1;
    }
    uint8_t value[MAX_QPS_LEN] = {0};
    size_t start_pos = MAX_QPS_LEN + restart_param_len + MAX_QPS_LEN + sign_len;
    if (get_key_value(digest_file, start_pos, MAX_QPS_LEN, value) < 0) {
        return -1;
    }
    return atoi(value);
}

int get_extend_license_config(const char* digest_file, char* out_client_id, int ext_license_length) {
    size_t restart_param_len = get_restart_param_length(digest_file);
    if (restart_param_len < 0) {
        fprintf(stderr, "get restart param length error\n");
        return -1;
    }

    size_t sign_len = get_sign_length(digest_file); 
    if (sign_len < 0) {
        fprintf(stderr, "get sign length error\n");
        return -1;
    }

    size_t start_pos = MAX_QPS_LEN + restart_param_len + MAX_QPS_LEN + sign_len + MAX_QPS_LEN;
    if (get_key_value(digest_file, start_pos, ext_license_length, out_client_id) < 0) {
        return -1;
    }
    return 0;
}

int get_sign_buf(const char* digest_file, char* out_sign_buf, int out_sign_buf_len) {
    size_t restart_param_len = get_restart_param_length(digest_file);
    if (restart_param_len < 0) {
        fprintf(stderr, "get restart param length error\n");
        return -1;
    }

    size_t sign_len = get_sign_length(digest_file); 
    if (sign_len < 0) {
        fprintf(stderr, "get sign length error\n");
        return -1;
    }

    if (sign_len > out_sign_buf_len) {
        fprintf(stderr, "the sign buffer size is smaller\n");
        return -1;
    }
    size_t start_pos = MAX_QPS_LEN + restart_param_len + MAX_QPS_LEN;
    if (get_key_value(digest_file, start_pos, sign_len, out_sign_buf) < 0) {
        return -1;
    }
    return sign_len;
}

int get_key_value(const char *digest_file, int start_pos, int value_len, char* value)
{
    if (!digest_file || access(digest_file, F_OK)) {
        fprintf(stderr, "file is not access: %s\n", digest_file);
        return -1;
    }

    FILE *fp = fopen(digest_file, "r");
    if (!fp) {
        fprintf(stderr, "file open failed\n");
        return -1;
    }

    size_t data_len = start_pos + value_len;
    uint8_t* data = (uint8_t*)malloc(sizeof(uint8_t) * (data_len+1));
    if (data == NULL) {
        fprintf(stderr, "malloc error\n");
       return -1; 
    }
    memset(data, 0, (data_len+1));

    size_t read_size = fread(data, 1, data_len, fp);
    if (read_size <= 0)
    {
        fprintf(stderr, "read size error\n");
        free(data);
        fclose(fp);
        return -1;
    }
    fclose(fp);

    int i = start_pos;
    int j = 0;
    for (; j < value_len; j++)
    {
        data[i + j] -= (j + QPS_SHIFT);
    }

    memcpy(value, data + start_pos, value_len);

    return 0;
}
