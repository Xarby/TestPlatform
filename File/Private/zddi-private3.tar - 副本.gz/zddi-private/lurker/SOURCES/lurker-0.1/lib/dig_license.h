#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include <openssl/evp.h>

#define MAX_KEY_LEN 10240
#define QPS_LIMIT       0
#define LPS_LIMIT       1
#define AUTH_LIMIT      2
#define ADD_LIMIT       3
#define AUTH_DNS_LIMIT  4
#define AUTH_DHCP_LIMIT 5
#define AUTH_ADD_LIMIT  6
#define AUTH_REG_LIMIT  7
#define MAX_EMPTY_SIZE 512
#define MACHINE_FILE_PATH "/usr/local/appsys/normal/config/public/machine.info"
int
check_digest_for_license(const char *public_key_file, const char *digest_file);

int 
get_limit(const char *digest_file, int type);