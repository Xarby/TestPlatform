#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/vfs.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>

#include "dig_fetch_info.h"

/* Default memory device file */
#ifdef __BEOS__
#define DEFAULT_MEM_DEV "/dev/misc/mem"
#else
#ifdef __sun
#define DEFAULT_MEM_DEV "/dev/xsvc"
#else
#define DEFAULT_MEM_DEV "/dev/mem"
#endif
#endif

/* Use mmap or not */
#ifndef __BEOS__
#define USE_MMAP
#endif

/* Use memory alignment workaround or not */
#ifdef __ia64__
#define ALIGNMENT_WORKAROUND
#endif

#ifdef USE_MMAP
#include <sys/mman.h>
#ifndef MAP_FAILED
#define MAP_FAILED ((void *) -1)
#endif /* !MAP_FAILED */
#endif /* USE MMAP */

#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))

typedef unsigned char u8;
typedef unsigned short u16;
typedef signed short i16;
typedef unsigned int u32;

#ifdef ALIGNMENT_WORKAROUND
#	ifdef BIGENDIAN
#	define WORD(x) (u16)((x)[1] + ((x)[0] << 8))
#	define DWORD(x) (u32)((x)[3] + ((x)[2] << 8) + ((x)[1] << 16) + ((x)[0] << 24))
#	else /* BIGENDIAN */
#	define WORD(x) (u16)((x)[0] + ((x)[1] << 8))
#	define DWORD(x) (u32)((x)[0] + ((x)[1] << 8) + ((x)[2] << 16) + ((x)[3] << 24))
#	endif /* BIGENDIAN */
#else /* ALIGNMENT_WORKAROUND */
#define WORD(x) (u16)(*(const u16 *)(x))
#define DWORD(x) (u32)(*(const u32 *)(x))
#endif /* ALIGNMENT_WORKAROUND */


struct dmi_header
{
	u8 type;
	u8 length;
	u16 handle;
	u8 *data;
};

static const char *dmi_string(const struct dmi_header *dm, u8 s);
static int checksum(const u8 *buf, size_t len);
static void *mem_chunk(size_t base, size_t len, const char *devmem);

#ifndef USE_MMAP
static int 
myread(int fd, u8 *buf, size_t count, const char *prefix)
{
	ssize_t r = 1;
	size_t r2 = 0;

	while (r2 != count && r != 0)
	{
		r = read(fd, buf + r2, count - r2);
		if (r == -1)
		{
			if (errno != EINTR)
			{
				close(fd);
				perror(prefix);
				return -1;
			}
		}
		else
			r2 += r;
	}

	if (r2 != count)
	{
		close(fd);
		fprintf(stderr, "%s: Unexpected end of file\n", prefix);
		return -1;
	}

	return 0;
}
#endif

static int 
checksum(const u8 *buf, size_t len)
{
	u8 sum = 0;
	size_t a;

	for (a = 0; a < len; a++)
		sum += buf[a];
	return (sum == 0);
}

/*
 * Copy a physical memory chunk into a memory buffer.
 * This function allocates memory.
 */
static void*
mem_chunk(size_t base, size_t len, const char *devmem)
{
	void *p;
	int fd;
#ifdef USE_MMAP
	size_t mmoffset;
	void *mmp;
#endif

	if ((fd = open(devmem, O_RDONLY)) == -1)
	{
		printf("No permission to access hardware info.\n");
		return NULL;
	}

	if ((p = malloc(len)) == NULL)
	{
		printf("Memory malloc failed\n");
		return NULL;
	}

#ifdef USE_MMAP
#ifdef _SC_PAGESIZE
	mmoffset = base % sysconf(_SC_PAGESIZE);
#else
	mmoffset = base % getpagesize();
#endif /* _SC_PAGESIZE */
	/*
	 * Please note that we don't use mmap() for performance reasons here,
	 * but to workaround problems many people encountered when trying
	 * to read from /dev/mem using regular read() calls.
	 */
	mmp = mmap(0, mmoffset + len, PROT_READ, MAP_SHARED, fd, base - mmoffset);
	if (mmp == MAP_FAILED)
	{
		fprintf(stderr, "%s: ", devmem);
		perror("mmap");
		free(p);
		return NULL;
	}

	memcpy(p, (u8 *)mmp + mmoffset, len);

	if (munmap(mmp, mmoffset + len) == -1)
	{
		fprintf(stderr, "%s: ", devmem);
		perror("munmap");
	}
#else /* USE_MMAP */
	if (lseek(fd, base, SEEK_SET) == -1)
	{
		fprintf(stderr, "%s: ", devmem);
		perror("lseek");
		free(p);
		return NULL;
	}

	if (myread(fd, p, len, devmem) == -1)
	{
		free(p);
		return NULL;
	}
#endif /* USE_MMAP */

	if (close(fd) == -1)
		perror(devmem);

	return p;
}

/*
 * Type-independant Stuff
 */
static const char*
dmi_string(const struct dmi_header *dm, u8 s)
{
	char *bp = (char *)dm->data;

	if (s == 0)
		return "Not Specified";

	bp += dm->length;
	while (s > 1 && *bp)
	{
		bp += strlen(bp);
		bp++;
		s--;
	}

	if (!*bp)
		return "Bad Index";

	return bp;
}

static void 
dmi_processor_id(const u8 *p, const char *prefix, char *id_info, size_t size)
{
    char tmp[1024] = {0};
    size_t tmp_size = sizeof(tmp);
    int ret = 0;
	ret = snprintf(tmp, tmp_size, "%sID: %02X %02X %02X %02X %02X %02X %02X %02X\n",
		  prefix, p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7]);
    if (ret)
        strncat(id_info, tmp, size - strlen(id_info));
}

static void
dmi_processor_frequency(const u8 *p, char *frequency_info, size_t size)
{
	u16 code = WORD(p);

    char tmp[1024] = {0};
    size_t tmp_size = sizeof(tmp);
    int ret = 0;
	if (code)
    {
		ret = snprintf(tmp, tmp_size, "%u MHz", code);
        if (ret)
            strncat(frequency_info, tmp, size - strlen(frequency_info));
    }
	else
    {
		ret = snprintf(tmp, tmp_size, "Unknown");
        if (ret)
            strncat(frequency_info, tmp, size - strlen(frequency_info));
    }
}

static void
dmi_decode(const struct dmi_header *h, char *hd_info, size_t size)
{
	const u8 *data = h->data;
    char tmp[1024] = {0};
    size_t tmp_size = sizeof(tmp);
    int ret = 0;

	/*
	 * Note: DMI types 37, 39 and 40 are untested
	 */
	switch (h->type)
	{
		case 0: /* 3.3.1 BIOS Information */
			ret = snprintf(tmp, tmp_size, "BIOS Information\n");
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			if (h->length < 0x12) break;
			ret = snprintf(tmp, tmp_size, "\tVendor: %s\n",
				dmi_string(h, data[0x04]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tVersion: %s\n",
				dmi_string(h, data[0x05]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tRelease Date: %s\n",
				dmi_string(h, data[0x08]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
            break;

		case 2: /* 3.3.3 Base Board Information */
			ret = snprintf(tmp, tmp_size, "Base Board Information\n");
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			if (h->length < 0x08) break;
			ret = snprintf(tmp, tmp_size, "\tManufacturer: %s\n",
				dmi_string(h, data[0x04]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tProduct Name: %s\n",
				dmi_string(h, data[0x05]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tVersion: %s\n",
				dmi_string(h, data[0x06]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tSerial Number: %s\n",
				dmi_string(h, data[0x07]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			break;

		case 4: /* 3.3.5 Processor Information */
			ret = snprintf(tmp, tmp_size, "Processor Information\n");
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			if (h->length < 0x1A) break;
			dmi_processor_id(data + 8, "\t", hd_info, size);
			ret = snprintf(tmp, tmp_size, "\tVersion: %s\n",
				dmi_string(h, data[0x10]));
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			ret = snprintf(tmp, tmp_size, "\tMax Speed: ");
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
            dmi_processor_frequency(data + 0x14, hd_info, size);
            ret = snprintf(tmp, tmp_size, "\n");
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			break;
		default:
            break;
	}
}

static void
to_dmi_header(struct dmi_header *h, u8 *data)
{
	h->type = data[0];
	h->length = data[1];
	h->handle = WORD(data + 2);
	h->data = data;
}

static void
dmi_table(u32 base, u16 len, const char *devmem, char *hd_info, size_t size)
{
	u8 *buf;
	u8 *data;
	int i = 0;
    char tmp[1024] = {0};
    int tmp_size = sizeof(tmp);
    int ret = 0;

	if ((buf = mem_chunk(base, len, devmem)) == NULL)
	{
		ret = snprintf(tmp, tmp_size, "Table is unreachable, sorry.\n");
        if (ret)
            strncat(hd_info, tmp, size - strlen(hd_info));
		return;
	}

	data = buf;
	while (i < 5 && data + 4 <= buf + len) /* 4 is the length of an SMBIOS structure header */
	{
		u8 *next;
		struct dmi_header h;

		to_dmi_header(&h, data);

		/*
		 * If a short entry is found (less than 4 bytes), not only it
		 * is invalid, but we cannot reliably locate the next entry.
		 * Better stop at this point, and let the user know his/her
		 * table is broken.
		 */
		if (h.length < 4)
		{
			ret = snprintf(tmp, tmp_size, "Invalid entry length (%u). DMI table is "
			       "broken! Stop.\n\n", (unsigned int)h.length);
            if (ret)
                strncat(hd_info, tmp, size - strlen(hd_info));
			break;
		}

		/* look for the next handle */
		next = data + h.length;
		while (next - buf + 1 < len && (next[0] != 0 || next[1] != 0))
			next++;
		next += 2;
        dmi_decode(&h, hd_info, size);
		data = next;
		i++;
	}

	free(buf);
}

static int
smbios_decode(u8 *buf, const char *devmem, char *hd_info, size_t size)
{
	if (!checksum(buf, buf[0x05])
	    || memcmp(buf + 0x10, "_DMI_", 5) != 0
	    || !checksum(buf + 0x10, 0x0F))
		return 0;

	dmi_table(DWORD(buf + 0x18), WORD(buf + 0x16), devmem, hd_info, size);
	return 1;
}

static int
legacy_decode(u8 *buf, const char *devmem, char *hd_info, size_t size)
{
	if (!checksum(buf, 0x0F))
		return 0;

	dmi_table(DWORD(buf + 0x08), WORD(buf + 0x06), devmem, hd_info, size);
	return 1;
}

/*
 * Probe for EFI interface
 */
#define EFI_NOT_FOUND   (-1)
#define EFI_NO_SMBIOS   (-2)
static int
address_from_efi(size_t *address)
{
	FILE *efi_systab;
	const char *filename;
	char linebuf[64] = {0};
	int ret;

	*address = 0; /* Prevent compiler warning */

	/*
	 * Linux up to 2.6.6: /proc/efi/systab
	 * Linux 2.6.7 and up: /sys/firmware/efi/systab
	 */
	if ((efi_systab = fopen(filename = "/sys/firmware/efi/systab", "r")) == NULL
	 && (efi_systab = fopen(filename = "/proc/efi/systab", "r")) == NULL)
	{
		/* No EFI interface, fallback to memory scan */
		return EFI_NOT_FOUND;
	}
	ret = EFI_NO_SMBIOS;
	while ((fgets(linebuf, sizeof(linebuf) - 1, efi_systab)) != NULL)
	{
		char *addrp = strchr(linebuf, '=');
		*(addrp++) = '\0';
		if (strcmp(linebuf, "SMBIOS") == 0)
		{
			*address = strtoul(addrp, NULL, 0);
			ret = 0;
			break;
		}
	}
	if (fclose(efi_systab) != 0)
		perror(filename);

	if (ret == EFI_NO_SMBIOS)
		fprintf(stderr, "%s: SMBIOS entry point missing\n", filename);
	return ret;
}

// Get Memory information
static void
get_mem_info(char *mem_info, size_t size, int direction)
{
    #if 0
    struct sysinfo si;
    sysinfo(&si);
    long iTotalCapacity = (((((float)si.totalram) / (1024 * 1024))) / 100);
    #else
    long iTotalCapacity = 111;
    #endif

    iTotalCapacity =  iTotalCapacity * 100;
    if (direction == 1) {
        iTotalCapacity += 100;
    } else if (direction == -1) {
        iTotalCapacity -= 100;
    }
    char tmp[1024] = {0};
    int tmp_size = sizeof(tmp);
    int ret = 0;
    ret = snprintf(tmp, tmp_size, "Memory Information\n");
    if (ret)
        strncat(mem_info, tmp, size - strlen(mem_info));
    ret = snprintf(tmp, tmp_size, "\tTotal Size: %ldM\n", iTotalCapacity);
    if (ret)
        strncat(mem_info, tmp, size - strlen(mem_info));
}

// Get HardDisk information
static void get_disk_info(char *disk_info, size_t size, int direction)
{
    #if 0
    struct statfs diskStatfs;
    statfs("/", &diskStatfs);
    long iTotalCapacity = (diskStatfs.f_blocks * ((float)diskStatfs.f_bsize / (1024 * 1024))) / 100;
    #else
    long iTotalCapacity = 401311184;
    #endif

    char tmp[1024] = {0};
    int tmp_size = sizeof(tmp);
    int ret = 0;


    iTotalCapacity = iTotalCapacity * 100;
    if (direction == 1) {
        iTotalCapacity += 100;
    } else if (direction == -1) {
        iTotalCapacity -= 200;
    }
    ret = snprintf(tmp, tmp_size, "HardDisk Information\n");
    if (ret)
        strncat(disk_info, tmp, size - strlen(disk_info));
    ret = snprintf(tmp, tmp_size, "\tTotal Size: %ldM\n", iTotalCapacity);
    if (ret)
        strncat(disk_info, tmp, size - strlen(disk_info));
}

static int
get_dmi_info(char *hd_info, size_t size)
{
	size_t fp;
	int efi;
	u8 *buf = NULL;


    // bios, processor and base board information
	// Set default option values
	const char *devmem = DEFAULT_MEM_DEV;
	if (sizeof(u8) != 1 || sizeof(u16) != 2 || sizeof(u32) != 4 || '\0' != 0)
		return -1;

	// First try EFI (ia64, Intel-based Mac)
	efi = address_from_efi(&fp);

    if (efi == EFI_NO_SMBIOS)
        return -1;
    else if (efi == EFI_NOT_FOUND)
    {
        // Fallback to memory scan (x86, x86_64)
        if ((buf = mem_chunk(0xF0000, 0x10000, devmem)) == NULL)
            return -1;

        for (fp = 0; fp <= 0xFFF0; fp += 16)
        {
            if (memcmp(buf + fp, "_SM_", 4) == 0 && fp <= 0xFFE0)
            {
                if (smbios_decode(buf+fp, devmem, hd_info, size))
                    fp += 16;
                else if (memcmp(buf + fp, "_DMI_", 5) == 0)
                    legacy_decode(buf + fp, devmem, hd_info, size);
            }
        }
    }

	if ((buf = mem_chunk(fp, 0x20, devmem)) == NULL)
		return -1;

	smbios_decode(buf, devmem, hd_info, size);
    free(buf);
    return 0;
}

#define NAMSIZE 16
#define MACSIZE 18
// data structs to store interface name list
char ifname_buf[MAX_INFO_LEN];
char *ifnames = ifname_buf;

char ifmac_buf[MAX_INFO_LEN];
char *ifmacs = ifmac_buf;

int INTERFACE_COUNT = 0;
int MAC_COUNT = 0;

static void
add_interface_name(const char *name)
{
    int i;
    for (i=0; i < INTERFACE_COUNT; i++) {
        // remove duplicate interface name
        if (!strcmp(name, ifnames + i * NAMSIZE))
            return;
    }
    strncpy(ifnames + (INTERFACE_COUNT++) * NAMSIZE, name, NAMSIZE - 1);
}

static void
add_mac_address(const char *mac)
{
    int i;
    for (i=0; i < MAC_COUNT; i++) {
        // remove duplicate mac address
        if (!strcmp(mac, ifmacs + i * MACSIZE))
            return;
    }
    strncpy(ifmacs + (MAC_COUNT++) * MACSIZE, mac, MACSIZE - 1);
}

static char*
get_name(char *name, char *p)
{
    while (isspace(*p))
        p++;

    while (*p) {
        if (isspace(*p))
            break;
        if (*p == ':') {    /* could be an alias */
            char *dot = p, *dotname = name;
            *name++ = *p++;
            while (isdigit(*p))
                *name++ = *p++;
            if (*p != ':') {    /* it wasn't, backup */
                p = dot;
                name = dotname;
            }
            if (*p == '\0')
                return NULL;
            p++;
            break;
        }
        *name++ = *p++;
    }
    *name++ = '\0';
    return p;
}

// get /proc/net/dev interface name list into buffer
// return 0 if success
static int
get_procnet_list()
{
    FILE *fh;
    char buf[512];
    fh = fopen("/proc/net/dev", "r");
    if (!fh) {
        return -1;
    }

    fgets(buf, sizeof buf, fh); /* eat title lines */
    fgets(buf, sizeof buf, fh);
    while (fgets(buf, sizeof buf, fh)) {
        char name[NAMSIZE];
        get_name(name, buf);
        add_interface_name(name);
    }
    fclose(fh);
    return 0;
}

// sort mac address
static void
sort_mac(char *p)
{
    char *pmax, *pmin, t[MACSIZE];
    int i, j;
    for (i = 0; i < MAC_COUNT; i++) {
        pmax= p + MACSIZE * i;
        for (j = i; j < MAC_COUNT; j++) {
            pmin=p + MACSIZE * j;
            if (strcmp(pmax, pmin) <= 0) {
                continue;
            }
            strncpy(t, pmax, MACSIZE - 1);
            strncpy(pmax, pmin, MACSIZE - 1);
            strncpy(pmin, t, MACSIZE - 1);
        }
    }
}

// get mac info
static int
get_mac_info(char *mac_info, size_t size)
{
    /* implementation for Linux */
    struct ifreq ifr;
    struct ifreq *IFR;
    struct ifconf ifc;
    char buf[1024] = {0};
    int ret = 0;
    char tmp[18] = {0};
    size_t tmp_size = sizeof(tmp);
    int s, i;

    // clear variables 
    INTERFACE_COUNT = 0;
    MAC_COUNT = 0;
    memset(ifname_buf, 0, sizeof(ifname_buf));
    memset(ifmac_buf, 0, sizeof(ifname_buf));

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s == -1) {
        return -1;
    }

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = buf;
    ioctl(s, SIOCGIFCONF, &ifc);
    IFR = ifc.ifc_req;
    // put the ioctl interface names in the list
    for (i = ifc.ifc_len / sizeof(struct ifreq); --i >= 0; IFR++) {
        add_interface_name(IFR->ifr_name);
    }

    // put the /proc/net/dev interface names in the list
    get_procnet_list();

    ret = snprintf(tmp, tmp_size, "MAC Information\n");
    if (ret) {
        strncat(mac_info, tmp, size - strlen(mac_info));
    }

    // get the first mac address of eth* device hardware address
    for (i = 0; i < INTERFACE_COUNT; i++) {
        strcpy(ifr.ifr_name, ifnames + i * NAMSIZE);

        if (ioctl(s, SIOCGIFFLAGS, &ifr) != 0) {
            continue;
        }

        if (ifr.ifr_flags & IFF_LOOPBACK) {
            continue;
        }

        if (ioctl(s, SIOCGIFHWADDR, &ifr) != 0) {
            continue;
        }

        char mac[MACSIZE] = {0};
        ret = snprintf(mac, MACSIZE, "%02x:%02x:%02x:%02x:%02x:%02x\0",
                (unsigned char)ifr.ifr_hwaddr.sa_data[0],
                (unsigned char)ifr.ifr_hwaddr.sa_data[1],
                (unsigned char)ifr.ifr_hwaddr.sa_data[2],
                (unsigned char)ifr.ifr_hwaddr.sa_data[3],
                (unsigned char)ifr.ifr_hwaddr.sa_data[4],
                (unsigned char)ifr.ifr_hwaddr.sa_data[5]);
        if (ret) {
            add_mac_address(mac);
        }
    }

    sort_mac(ifmacs);

    for (i = 0; i < MAC_COUNT; i++) {
        strncat(mac_info, "\t", size - strlen(mac_info));
        strncat(mac_info, ifmacs + i * MACSIZE, size - strlen(mac_info));
        strncat(mac_info, "\n", size - strlen(mac_info));
    }
    close(s);
    return 0;
}

int
get_hardware_info(char *hd_info, size_t size, int mem_direction, int disk_direction)
{
    //get dmi info (bios, processor, base_board)
    if (-1 == get_dmi_info(hd_info, size))
        return -1;
    // memory information
    get_mem_info(hd_info, size, mem_direction);
    // disk information
    get_disk_info(hd_info, size, disk_direction);
    // mac information
    // get_mac_info(hd_info, size);

    return strlen(hd_info);
}
