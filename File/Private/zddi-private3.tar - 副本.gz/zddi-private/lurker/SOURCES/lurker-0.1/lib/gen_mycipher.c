#include <stdio.h>
const char *SCRIPT = "\
#!/usr/local/bin/ruby\n\
require \'openssl\'\n\
require \'fileutils\'\n\
ENCODE_FLAG = \".encode.already\"\n\
DECODE_FLAG = \".decode.already\"\n\
REQUIRED_FLAG=\".required.must\"\n\
module DDI\n\
class Mycipher\n\
    def initialize(key)\n\
        @key = key\n\
    end\n\
\n\
    def des_encrypt(text, key, iv)\n\
        return if text.empty?\n\
        c = OpenSSL::Cipher::Cipher.new('DES-CBC')\n\
        c.encrypt\n\
        c.key = key\n\
        c.iv = iv\n\
        ret = c.update(text)\n\
        ret << c.final\n\
    end\n\
\n\
    def des_decrypt(encrypt_value, key, iv)\n\
        return if encrypt_value.empty?\n\
        c = OpenSSL::Cipher::Cipher.new('DES-CBC')\n\
        c.decrypt\n\
        c.key = key\n\
        c.iv = iv\n\
        ret = c.update(encrypt_value)\n\
        ret << c.final\n\
    end\n\
\n\
    def filetostring(filepath)\n\
        f = File.open(filepath, 'rb')\n\
        text = f.read\n\
        f.close\n\
        text\n\
    end\n\
\n\
    def stringtofile(filepath, string)\n\
        f = File.open(filepath, 'wb')\n\
        f.print string\n\
        f.close\n\
    end\n\
\n\
    def encode(filepath)\n\
        text = filetostring (filepath)\n\
        en = des_encrypt( text, @key, @key)\n\
        stringtofile(filepath, en)\n\
    end\n\
\n\
    def decode(filepath, outfile)\n\
        en = filetostring(filepath)\n\
        text = des_decrypt(en, @key, @key) \n\
        `cp -a #{filepath} #{outfile}`\n\
        stringtofile(outfile, text)\n\
    end\n\
\n\
    def encode_dir(dir)\n\
        Dir::foreach(dir) do |file|\n\
            return if file == ENCODE_FLAG\n\
        end\n\
        Dir::foreach(dir) do |file|\n\
            next if [\".\", \"..\", ENCODE_FLAG, DECODE_FLAG].include?(file)\n\
            file = File.join(dir, file)\n\
            encode_dir(file) if File.directory?(file)\n\
            encode(file) if File.file?(file)\n\
        end\n\
        FileUtils.touch(File.join(dir, ENCODE_FLAG))\n\
    end\n\
\n\
    def decode_dir(dir, dest_dir)\n\
        Dir::foreach(dir) do|file|\n\
            if file == REQUIRED_FLAG\n\
                FileUtils::mkdir_p(File.dirname(dest_dir)) unless File.exists?(File.dirname(dest_dir))\n\
                FileUtils::cp_r(dir, dest_dir)\n\
                return\n\
            end\n\
        end\n\
        Dir::foreach(dir) do|file|\n\
            return if file == DECODE_FLAG\n\
        end\n\
        Dir::foreach(dir) do|file|\n\
            next if [\".\", \"..\", ENCODE_FLAG, DECODE_FLAG].include?(file)\n\
            encry_file = File.join(dir, file)\n\
            if File.directory?(encry_file)\n\
                decode_dir(encry_file, File.join(dest_dir, file))\n\
            end\n\
            if File.file?(encry_file)\n\
                begin\n\
                    decode(encry_file, encry_file + \".origin.knet\")\n\
                    work_file = File.join(dest_dir, file)\n\
                    FileUtils::mkdir_p(File.dirname(work_file)) unless File.exists?(File.dirname(work_file))\n\
                    FileUtils::mv(encry_file+\".origin.knet\", work_file)\n\
                rescue\n\
                end\n\
            end\n\
        end\n\
    end\n\
\n\
end\n\
end\n\
if $0 == __FILE__\n\
    if ARGV.length < 3\n\
        puts \"usage: #{$0} en src_dir key| #{$0} de src_dir dest_dir key\"\n\
        exit 1\n\
    end\n\
    if ARGV[0] == \"en\"\n\
        my = DDI::Mycipher.new(ARGV[2])\n\
        my.encode_dir(ARGV[1]) if File.directory?(ARGV[1])\n\
        my.encode(ARGV[1]) if File.file?(ARGV[1])\n\
    else ARGV[0] == \"de\"\n\
        my = DDI::Mycipher.new(ARGV[3])\n\
        my.decode_dir(ARGV[1], ARGV[2]) if File.directory?(ARGV[1])\n\
        my.decode(ARGV[1], ARGV[2]) if File.file?(ARGV[1])\n\
    end\n\
end\n\
";
int gen_cipher(const char *file_path)
{
    FILE *fp = fopen(file_path, "w");
    fprintf(fp, "%s", SCRIPT);
    fclose(fp);
    char command[1024];
    sprintf(command, "chmod u+x %s", file_path);
    system(command);
}

int del_cipher(const char *file_path)
{
    char command[1024];
    sprintf(command, "rm -rf %s", file_path);
    system(command);
}
