#ifndef _FETCH_INFO_H
#define _FETCH_INFO_H

#include<stdio.h>

#define MAX_INFO_LEN 2048
/*
 * Get host hardware infomation
 *
 * @param hd_info : the str which stores hardware info
 * @param size : the max size of hd_info
 *
 * return 0 or -1 if failed, otherwise the length of hd_info
 */
int get_hardware_info(char *hd_info, size_t size, int mem_direction, int disk_direction);

#endif
