#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <time.h> 
#include "lib/dig_license.h"
#include "lib/gen_mycipher.h"
#include "openssl/md5.h" 
#define PROJECT_PATH "/usr/local/appsys/tmp/code"
#define PATH_MAX_LEN  10
#define PATH_DEPTH  3
#define COMMAND_MAX_LEN  2048
#define FILE_PATH_MAX_LEN  2048
#define FILE_LEN 512
#define MAX_DATETIME_LEN 20
#define MAX_CLIENT_ID_LEN 33
const char *MYCIPHER_FILE_PATH = "/usr/bin/mycipher";
const char *KEY = "zddi@knet.cn@zddigroup@20140303101010";
static void print_help()
{
    fprintf(stderr, "Usage: undergrounder [OPTION]...\n");
    fprintf(stderr, "Supported options:\n"
            "encry project_path|such as undergrounder encry /root/zddi\n"
            "decry project_encryed_path role nic_name public_key_file licence_file\n"
            "such as undergrounder decry /root/zddi master eth0 /root/id.pub /root/test.license\n"
            "license_time /etc/license_file\n"
            );

}

void start_process(const char *src_encry_pro, const char *real_pro_path, char *role,
    char* restart_param, char* process)
{
    char command[COMMAND_MAX_LEN];
    sprintf(command, "cd %s/etc && ./restart %s:%s %s %s %s", real_pro_path, src_encry_pro,
            real_pro_path, role, restart_param, process);
    system(command);
}

static bool
file_exist_or_not(const char *filename)
{
    if(!access(filename, F_OK))
        return true;
    return false;
}

bool
validate_license(const char* public_key_file, const char *license_file)
{
    if (file_exist_or_not(public_key_file) == false) {
        printf("public key file %s not exist, please check!\n", public_key_file);
        return false;
    }
    if (file_exist_or_not(license_file) == false) {
        printf("license file %s not exist, please check!\n", license_file);
        return false;
    }

    if (!check_digest_for_license(public_key_file, license_file))
        return true;
    return false;
}

int main(int argc, char *argv[])
{
    if (argc != 7 && argc != 3 && argc != 4) {
        print_help();
        return -1;
    } 
    // check params
    if ((strcmp(argv[1], "decry") == 0 ) && (argc == 7)) {
        // validate public key && license file
        bool rtn = validate_license(argv[4], argv[5]);
        if (!rtn) {
            printf("license validate failed, please check!\n");
            return 2;
        }
        
        //mkdir directory
        {
            char command[COMMAND_MAX_LEN];
            sprintf(command, "mkdir -p %s", PROJECT_PATH);
            system(command);
        }

        // decry project
        gen_cipher(MYCIPHER_FILE_PATH);
        char command[COMMAND_MAX_LEN];
        sprintf(command, "mycipher de %s %s %s", argv[2], PROJECT_PATH, KEY);
        system(command);

        char restart_param[COMMAND_MAX_LEN] = {0};
        size_t len = get_restart_param(argv[5], restart_param, COMMAND_MAX_LEN);
        if (len <= 0){
            printf("get restart param error\n");
            return 2;
        }

        // start serrvices
        start_process(argv[2], PROJECT_PATH, argv[3], restart_param, argv[6]);
        del_cipher(MYCIPHER_FILE_PATH);
    }

    if (strcmp(argv[1], "license_time") == 0 && argc ==3)
    {
        char start_time[MAX_DATETIME_LEN] = {0};
        char number_days[MAX_DATETIME_LEN] = {0};
        char remote_auth[MAX_DATETIME_LEN] = {0};
        char license_file[FILE_LEN] = {0};
        char client_id[MAX_CLIENT_ID_LEN] = {0};
        int use_license = 0;
        int root_change_password = 0;

        
        strcat(license_file, argv[2]);
        //get extend license length
        int ext_license_len = -1;
        if ((ext_license_len = get_extend_license_length(license_file)) < 0) {
            printf("get extend license config length error\n");
            return 2;
        }

        char *license_config = (char*)malloc((ext_license_len +1) * sizeof(char));
        if (license_config == NULL) {
            printf("malloc license config error\n");
            return 2;
        }
        memset(license_config, 0, (ext_license_len+1));

        if (get_extend_license_config(license_file, license_config, ext_license_len) < 0) {
            printf("get extend license config error\n");
            free(license_config);
            return 2;
        }
        printf("%s\n", license_config);
        free(license_config);
    }

    if (strcmp(argv[1], "license") == 0 && argc == 3)
    {
        char restart_param[COMMAND_MAX_LEN] = {0};
        size_t len = get_restart_param(argv[2], restart_param, COMMAND_MAX_LEN);
        if (len <= 0){
            printf("get restart param error\n");
            return 2;
        }
        printf("%s\n", restart_param);
    }

    if (strcmp(argv[1], "check") == 0 && argc == 4)
    {
        bool rtn = validate_license(argv[2], argv[3]);
        if (!rtn) {
            printf("failed\n");
            return 2;
        }

        printf("success\n");
    }

    return 0;
}
