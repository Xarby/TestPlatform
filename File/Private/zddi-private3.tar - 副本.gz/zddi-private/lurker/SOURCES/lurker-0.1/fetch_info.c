#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
#include <string.h>

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>

#include "lib/dig_fetch_info.h"

#define MAX_FILE_PATH 512
#define SHA512_LEN  64

static void
print_help()
{
    fprintf(stderr, "Usage: fetch_info [option]\n");
    fprintf(stderr, "\noption is one of the following:\n");
    fprintf(stderr, "\t-o output file path for machine infomation.\n");
    fprintf(stderr, "\t-h print help info\n");
}

int
main(int argc, char *argv[])
{
    char file_path[MAX_FILE_PATH] = {0};
    int opt = -1;
    while ((opt = getopt(argc, argv, "ho:")) != -1) {
        switch (opt) {
            case 'h' :
                print_help();
                return 0;
            case 'o' :
                strncpy(file_path, optarg, MAX_FILE_PATH);
                break;
            default :
                print_help();
                return -1;
        }
    }

    // get machine info
    char buf[MAX_INFO_LEN] = {0};
    int buf_len = get_hardware_info(buf, MAX_INFO_LEN, 0, 0);
    if (buf_len < 0) {
        fprintf(stderr, "generate machine infomaiton failed\n");
        return -1;
    }


    // sha256 machine info
    uint8_t digest_buf[SHA512_LEN] = {0};
    SHA512((const unsigned char *)buf, buf_len, digest_buf);


    // write machine info into file
    FILE *fp = fopen(file_path, "w");
    if (!fp) {
        fprintf(stderr, "open info file failed\n");
        return -1;
    }
    size_t write_size = fwrite(digest_buf, sizeof(char), SHA512_LEN, fp);
    fclose(fp);
    if (write_size != SHA512_LEN) {
        fprintf(stderr, "write info into file failed\n");
        return -1;
    }

    return 0;
}
