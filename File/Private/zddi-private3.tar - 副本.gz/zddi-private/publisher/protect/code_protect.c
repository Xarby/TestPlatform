#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <time.h> 
#include "lib/gen_mycipher.h"
#define PATH_MAX_LEN  10
#define PATH_DEPTH  3
#define COMMAND_MAX_LEN  2048
#define FILE_LEN 512
const char *MYCIPHER_FILE_PATH = "/usr/bin/mycipher";
const char *KEY = "zddi@knet.cn@zddigroup@20140303101010";
static void print_help()
{
    fprintf(stderr, "Usage: code_encry [OPTION]...\n");
    fprintf(stderr, "Supported options:\n"
            "encry project_path|such as undergrounder encry /root/zddi\n"
            );

}

int main(int argc, char *argv[])
{
    char src_encry_pro[COMMAND_MAX_LEN];
    char dst_encry_pro[COMMAND_MAX_LEN];
    char command[1000];
    if (argc != 3 && argc != 4)
    {
        print_help();
        return -1;
    }
    if (strcmp(argv[1], "encry") == 0)
    {
        gen_cipher(MYCIPHER_FILE_PATH);
        strcpy(src_encry_pro, argv[2]);
        sprintf(command, "mycipher en %s %s", src_encry_pro, KEY);
        system(command);
        del_cipher(MYCIPHER_FILE_PATH);
    }
     if (strcmp(argv[1], "decry") == 0)
     {
         gen_cipher(MYCIPHER_FILE_PATH);
         strcpy(src_encry_pro, argv[2]);
         strcpy(dst_encry_pro, argv[3]);
         sprintf(command, "mycipher de %s %s %s", src_encry_pro, dst_encry_pro, KEY);
         system(command);
         del_cipher(MYCIPHER_FILE_PATH);
     }
    return 0;
}
