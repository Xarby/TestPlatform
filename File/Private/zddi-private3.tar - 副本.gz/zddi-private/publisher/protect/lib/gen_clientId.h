#ifndef __GEN_CLIENT_ID_H
#define __GEN_CLIENT_ID_H
int gen_client_id(const char* machine_file, char* client_id);
#endif
