#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <time.h> 
#include "openssl/md5.h" 

static void print_help()
{

#ifdef DECRY_PASSWORD 
    fprintf(stderr, "Usage: root_password_change_priv str  str: the root password encrypt string\n");
#else
    fprintf(stderr, "Usage: root_password_change /etc/machine.info\n");
#endif

}

bool file_exist_or_not(const char *filename)
{
    if(!access(filename, F_OK))
        return true;
    return false;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        print_help();
        return -1;
    }
    
    int i;
    time_t t;
    struct tm* ti;
    const size_t date_len = 9;
    char today[date_len];
    const size_t machine_data_len = 65;
    char machine_data[machine_data_len];
    const size_t origin_data_len = date_len + machine_data_len -1;
    char origin_data[origin_data_len];
    const size_t password_len = 17;
    unsigned char password[password_len];                                                                    
       
    int pt_index = 0; 
    int password_table[100] = {0};
    MD5_CTX ctx;
    const int root_password_len = 12;
    char new_root_password[root_password_len + 1];
    const int origin_password_len = 33;
    char origin_password[origin_password_len];
    char *log_path = "/usr/local/appdata/log";
    char *log_file = "/usr/local/appdata/log/zddi.log";

    {
        char command[100] = {0};
        sprintf(command, "mkdir -p %s; chmod 755 -R %s", log_path, log_path);
        system(command);
    }

#ifndef DECRY_PASSWORD 
    if (file_exist_or_not(argv[1]) == false) {
        printf("Error: not exist machine file:%s\n", argv[1]);
        return -1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Error: open machine file error\n");
        return -1;
    }
        
    memset(machine_data, 0, machine_data_len);
    size_t read_size = fread(machine_data, sizeof(char), 64, fp);
    if (read_size < machine_data_len - 1) {
        printf("Error: read machine data error\n");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    time(&t);
    ti = localtime(&t);
    memset(today, 0, date_len);
    sprintf(today, "%02d%02d%02d", ti->tm_year + 1900, ti->tm_mon + 1, ti->tm_mday);

    memset(origin_data, 0, origin_data_len);
    if (ti->tm_mday % 2 == 0) {
        memcpy(origin_data, machine_data, machine_data_len);
        memcpy(origin_data + machine_data_len - 1, today, date_len);
    } else {
        memcpy(origin_data, today, date_len);
        memcpy(origin_data + date_len - 1, machine_data, machine_data_len);
    }

    {
       //add hour to origin_data
       origin_data[0] += ti->tm_hour;
       origin_data[0] += ti->tm_min;
    }

    { 
        char command[100] = {0};
        memset(password, 0, password_len);

        MD5_CTX tctx;
        MD5_Init(&tctx);
        MD5_Update(&tctx, origin_data, origin_data_len);
        MD5_Final(password, &tctx);
        memset(origin_password, 0, origin_password_len);
        for (i = 0; i < password_len - 1; ++i)
            sprintf(origin_password + i * 2, "%02x", password[i]);

        system("mkdir -p /usr/local/appdata/config/public");
        sprintf(command, "echo %s > /usr/local/appdata/config/public/._root_password_sign.file", origin_password);
        int status = system(command);

        memset(command, 0, 100);
        sprintf(command, "echo \"save root password string to file result: %d\" >> %s", status, log_file);
        system(command);

        //for not install cli and root change password
        system("rm -rf /home/lshell-users/admin/._root_sign_file");
        system("cp -rf /usr/local/appdata/config/public/._root_password_sign.file /home/lshell-users/admin/._root_sign_file");
        system("chmod a+rx /home/lshell-users/admin/._root_sign_file");
    }
#else
    int tmp_password_len = 32;
    memset(origin_password, 0, origin_password_len);
    if (strlen(argv[1]) < tmp_password_len) {
        tmp_password_len = strlen(argv[1]);
    }
    memcpy(origin_password, argv[1], tmp_password_len);
#endif
    {
        for (i = 0; i < origin_password_len - 1 ; ++i) {
           origin_password[i] = origin_password[i] + (int)origin_password[i] / 2; 
        }
    }
    memset(password, 0, password_len);
    MD5_Init(&ctx);
    MD5_Update(&ctx, origin_password, origin_password_len);
    MD5_Final(password, &ctx);

    //init password table
    pt_index = 0;
    for(i = (int)'a'; i <= (int)'z'; ++i) {
        password_table[pt_index++] = i;
    }
    for (i = (int)'A'; i <= (int)'Z'; ++i) {
        password_table[pt_index++] = i;
    }
    for (i = 0; i <= 9; ++i) {
        password_table[pt_index++] = i + 48;
    }
    password_table[pt_index++] = '@';
    password_table[pt_index++] = '#';
    password_table[pt_index++] = '$';
    password_table[pt_index++] = '%';
    password_table[pt_index++] = '^';
    password_table[pt_index++] = '!';
    password_table[pt_index++] = '&';
    password_table[pt_index++] = '*';

    memset(new_root_password, 0, root_password_len + 1);
    if (((int)password[0]) % 2) {
        for (i = password_len - root_password_len ; i < password_len; ++i) {
            int t = (int)password[i];
            t = t > 0 ? t : -t;
            
            new_root_password[i - (password_len - root_password_len)] = password_table[t % pt_index];
        }
    } else {
        for (i = 0; i< root_password_len && i < password_len; ++i) {
            int t = (int)password[i];
            t = t > 0 ? t : -t;
            new_root_password[i] = password_table[t % pt_index];
        }
    }
#ifdef DECRY_PASSWORD 
    printf("%s\n", new_root_password);
    return 0;
#endif
    {
        char command[100] = {0};
        new_root_password[root_password_len] = '\0';
        sprintf(command, "echo '%s' | passwd --stdin 'root'", new_root_password);
        int status = system(command);
        memset(command, 0, 100);
        sprintf(command, "echo \"modify root password result: %d\" >> %s", status, log_file);
        system(command);
    }
    return 0;
}
