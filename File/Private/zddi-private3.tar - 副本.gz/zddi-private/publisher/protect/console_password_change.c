#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <time.h> 
#include "openssl/md5.h" 
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>

//const char *run_machine_mac = "00:50:56:b1:4a:31";
const char *run_machine_mac = "00:50:56:b1:4a:31";

void check_machine() {
    struct ifreq ifreq;
    int sock;

    if((sock=socket(AF_INET,SOCK_STREAM,0)) < 0)
    {
        perror("socket");
        exit(0);
        return ;
    }
    
    strcpy(ifreq.ifr_name, "eth0");
    if(ioctl(sock,SIOCGIFHWADDR, &ifreq) < 0)
    {
        perror("ioctl");
        exit(0);
        return ;
    }

    char mac[18];
    sprintf(mac, "%02x:%02x:%02x:%02x:%02x:%02x",
        (unsigned char)ifreq.ifr_hwaddr.sa_data[0],
        (unsigned char)ifreq.ifr_hwaddr.sa_data[1],
        (unsigned char)ifreq.ifr_hwaddr.sa_data[2],
        (unsigned char)ifreq.ifr_hwaddr.sa_data[3],
        (unsigned char)ifreq.ifr_hwaddr.sa_data[4],
        (unsigned char)ifreq.ifr_hwaddr.sa_data[5]);

    if (strncmp((const char*)run_machine_mac, (const char*)mac, 17))
    {
        printf("run machine is not allow\n");
        exit(0);
    }
}

static void print_help()
{

#ifdef DECRY_PASSWORD 
    fprintf(stderr, "Usage: console_password_change_priv str  str: the console password encrypt string\n");
#else
    fprintf(stderr, "Usage: console_password_change /etc/machine.info\n");
#endif

}

bool file_exist_or_not(const char *filename)
{
    if(!access(filename, F_OK))
        return true;
    return false;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        print_help();
        return -1;
    }
    
    int i;
    time_t t;
    struct tm* ti;
    const size_t date_len = 9;
    char today[date_len];
    const size_t machine_data_len = 65;
    char machine_data[machine_data_len];
    const size_t origin_data_len = date_len + machine_data_len -1;
    char origin_data[origin_data_len];
    const size_t password_len = 20;
    unsigned char password[password_len + 1];                                                                    
       
    int pt_index = 0; 
    int password_table[100] = {0};
    MD5_CTX ctx;
    const int console_password_len = 20;
    char new_console_password[console_password_len + 1];
    int origin_password_len = 34;
    char origin_password[origin_password_len];
    const char specilal_str[] = "@#$%^&!*";

#ifdef DECRY_PASSWORD
//    check_machine();
#endif

#ifndef DECRY_PASSWORD 
    if (file_exist_or_not(argv[1]) == false) {
        printf("Error: not exist machine file:%s\n", argv[1]);
        return -1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        printf("Error: open machine file error\n");
        return -1;
    }
        
    memset(machine_data, 0, machine_data_len);
    size_t read_size = fread(machine_data, sizeof(char), 64, fp);
    if (read_size < machine_data_len - 1) {
        printf("Error: read machine data error\n");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    time(&t);
    ti = localtime(&t);
    memset(today, 0, date_len);
    sprintf(today, "%02d%02d%02d", ti->tm_year + 1900, ti->tm_mon + 1, ti->tm_mday);

    memset(origin_data, 0, origin_data_len);
    if (ti->tm_mday % 2 == 0) {
        memcpy(origin_data, machine_data, machine_data_len);
        memcpy(origin_data + machine_data_len - 1, today, date_len);
    } else {
        memcpy(origin_data, today, date_len);
        memcpy(origin_data + date_len - 1, machine_data, machine_data_len);
    }

    {
       //add hour to origin_data
       origin_data[0] += ti->tm_hour;
       origin_data[0] += ti->tm_min;
    }

    { 
        char command[100] = {0};
        memset(password, 0, password_len);

        MD5_CTX tctx;
        MD5_Init(&tctx);
        MD5_Update(&tctx, origin_data, origin_data_len);
        MD5_Final(password, &tctx);
        memset(origin_password, 0, origin_password_len);
        origin_password[0] = 'a';
        for (i = 0; i < password_len - 1; ++i)
            sprintf(origin_password + i * 2 + 1, "%02x", password[i]);
        printf("%s\n", origin_password);
    }
#else
    int tmp_password_len = 33;
    memset(origin_password, 0, origin_password_len);
    if (strlen(argv[1]) < tmp_password_len) {
        tmp_password_len = strlen(argv[1]);
    }
    memcpy(origin_password, argv[1], tmp_password_len);
#endif
    int radom_num = 0;
    for (i = 0; i < console_password_len; ++i) {
        switch ((int)origin_password[i] % 4) {
            // low letters
            case 0:
                radom_num = (int)origin_password[i] % 26;
                new_console_password[i] = 'a' + radom_num;
                break;
            // number
            case 1:
                radom_num = (int)origin_password[i] % 10;
                new_console_password[i] = '0' + radom_num;
                break;
            // special letters
            case 2:
                radom_num = (int)origin_password[i] % strlen(specilal_str);
                new_console_password[i] = specilal_str[radom_num];
                break;
            // upper letters
            case 3:
                radom_num = (int)origin_password[i] % 26;
                new_console_password[i] = 'A' + radom_num;
                break;
        }
    }
    new_console_password[console_password_len] = '\0';
#ifdef DECRY_PASSWORD 
    printf("%s\n", new_console_password);
    return 0;
#endif
    {
        char command[100] = {0};
        sprintf(command, "echo '%s' | passwd --stdin '_consoleuser' 2>&1 >/dev/null", new_console_password);
        int status = system(command);
        memset(command, 0, 100);
        sprintf(command, "echo \"modify console password result: %d\" >> /var/log/messages", status);
        system(command);
    }
    return 0;
}
