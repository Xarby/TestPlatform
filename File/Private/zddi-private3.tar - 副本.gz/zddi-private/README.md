## 此分支用于制作新版本的license和root密码。
## lurker打包已经内置openssl-1.0.2版本（在centos7.8 x86架构编译得到），打包时使用静态链接编译


## zddi-3.11 对应的是从3.11.2.17版本开始使用
- 1) [3.13.2.0版本的修改]
    - [f70c140886ee50a7703807a1f6a4d2f7563146f6] 去掉了license_flag、license_control_node_num、license_normal_flag、license_virtual_validate、user_name、license_type、elk、sgcloud_st_time、sgcloud_vaild_days、sgcloud_role、reg、proxy、grade、zcloud、sgcloud 参数;dns从0-3修改为0和3， dhcp从0-2修改为0-1;
    - [b15305d0790f6e9001f2fa98e5ec0875b3491066] 在zddi-old的基础上面，做了license精简[3.13版本]ADD：从0-2修改为1-2【去掉了0的取值】
    - 调整了内存和磁盘的大小为固定大小
    - [b7aca2e712c96c2deb068b0afb0828ca97298861] Mar 5修改了license_start_time的格式，从%F %T修改为%Y-%m-%d 00:00:00
- 2) [3.15.2.0版本的修改]
    - [83a9bea06392c177b1261f694b2e0e4109e866a4] 合并zddi-4.2到zddi-3.11, 增加publish_1230目录。 不影响原来的publisher和lurker目录
- 3) [3.16版本的修改]
    - [efe6337a04c3b2f4736ceae5737b362f534b91a0] license增加虚拟化平台类型，lurker校验时除校验原有机器信息，还可通过校验虚拟化平台license

## license内容的说明
### 目前还存在的license内容
- 从3.13.2.0版本以后只存在如下的内容
-s --license_start_time 生效时间戳
-D --license_valid_days 有效天数
-S --license_remote_auth_flag 远程认证开关
-m --root_change_password root密码时变
-M --device_type 设备类型
-N --dns DNS版本
-H --dhcp DHCP版本
-A --add ADD版本
-Q ---qps QPS限制
-L --LPS LPS限制

### 已经删除的license内容
- 下面的license内容是在3.13.2.0版本开始删除
-u --use_license //是否启动license；所有软件都提供license，因此不需要此项；
-P --license_control_node_num //虚拟机的管理节点数；技术方案有缺陷，不使用该方案；
-T --license_normal_flag //license普通标记；技术方案有缺陷，不使用该方案；
-V --license_virtual_validate //虚拟验证；技术方案有缺陷，不使用该方案；
-t --license_type //license类型；技术方案有缺陷，不使用该方案；
-U --user_name //license使用的用户名；技术方案有缺陷，不使用该方案；
-E --elk //支持ELK；主线不支持ELK，不使用该方案；
-F --sgcloud //云端拉去域名库；新版本在云端控制license授权，不使用设备授权（云端授权需求单独提供）；
-K --sgcloud_st_time //sgcloud生效时间戳；新版本在云端控制license授权，不使用设备授权（云端授权需求单独提供）；
-W --sgcloud_vaild_days //sgcloud有效天数；新版本在云端控制license授权，不使用设备授权（云端授权需求单独提供）；
-J --sgcloud_role //sgcloud角色；新版本在云端控制license授权，不使用设备授权（云端授权需求单独提供）；
-R --reg //域名自注册；新版本默认提供域名注册功能，不做限制；
-X --proxy //支持reverse 代理；新版本默认提供反向代理功能，不做限制；
-G --grade //安全管理级别；新版本默认提供所有安全功能，不做限制；
-Z --zcloud //云服务联动；新版本不支持云服务联动，不使用该方案；